package com.capgemini.userprofilemgmtmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfileMgmtMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
