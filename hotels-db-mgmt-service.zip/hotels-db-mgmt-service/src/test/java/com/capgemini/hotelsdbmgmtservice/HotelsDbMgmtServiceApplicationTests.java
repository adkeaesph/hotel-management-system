package com.capgemini.hotelsdbmgmtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelsDbMgmtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
