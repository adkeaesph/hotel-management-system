package com.capgemini.hotelsdbmgmtservice.customexceptions;

public class HotelDeletionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7509608409407499155L;

	public HotelDeletionException(String message) {
		super(message);
	}
}
