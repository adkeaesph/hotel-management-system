package com.capgemini.hotelsdbmgmtservice.customexceptions;

public class HotelReAdditionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2407116311639282019L;

	public HotelReAdditionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
