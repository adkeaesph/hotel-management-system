package com.capgemini.hotelsdbmgmtservice.dao;


import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.hotelsdbmgmtservice.entities.HotelEntity;
import com.capgemini.hotelsdbmgmtservice.entities.ScheduleStayEntity;

@Repository
public interface ScheduleStayDAO extends JpaRepository<ScheduleStayEntity, Integer> {
	@Query("SELECT COUNT(*) FROM ScheduledStay WHERE HotelName=?1 AND (CheckinDate<=?2 OR CheckoutDate>=?3)")
	long findOccupiedRooms(String hotelName,Date checkIn,Date checkOut);

}
