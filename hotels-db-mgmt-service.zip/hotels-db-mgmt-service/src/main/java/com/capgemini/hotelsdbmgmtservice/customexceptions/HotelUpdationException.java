package com.capgemini.hotelsdbmgmtservice.customexceptions;

public class HotelUpdationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3304955464937815281L;

	public HotelUpdationException(String message) {
		super(message);
	}
	
}
