package com.capgemini.hotelsdbmgmtservice.customexceptions;

public class HotelCreationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8373623198676391411L;

	public HotelCreationException(String message) {
		super(message);
	}
}
